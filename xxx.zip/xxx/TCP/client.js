const net = require('net')
const format= require('./format.js')
const client = net.createConnection({
    host: '127.0.0.1',
    port: 8989
})

let myName = null

client.on('connect', () => {
    process.stdout.write(`来将报上姓名:`)
    process.stdin.on('data', data => {
        let newData = data.toString().trim()
        if(!myName) {
            return client.write(JSON.stringify({
                type:format.lg,
                name:newData
            }))
        }
        client.write(JSON.stringify({
            type:format.al,
            myName:myName,
            message:newData
        }))
    })
})

client.on('data', data => {
    let json = JSON.parse(data.toString().trim())
    switch(json.type) {
        case format.lg:
            if(!json.success) process.stdout.write(`${json.message}`)
            else {
                console.log(`${json.message}`);
                myName = json.name
            }
            break
        case format.al:
            console.log(`${json.who}:${json.message}`)
            break
    }
})