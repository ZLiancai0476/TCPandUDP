module.exports = {
    lg: 0,
    al: 1
}