const net = require('net');
const format = require('./format.js')
const server = net.createServer()

const nameList = []

server.on('connection', clientScoket => {
    clientScoket.on('data', data => {
        let json = JSON.parse(data.toString().trim())
        switch (json.type) {
            case format.lg:
                if (nameList.find(item => item.name === json.name)) {
                    return clientScoket.write(JSON.stringify({
                        type: format.lg,
                        success: false,
                        message: '登陆失败,名字重复,请重新设置名字:',
                    }))
                }
                nameList.push(clientScoket)
                clientScoket.write(JSON.stringify({
                    type: format.lg,
                    success: true,
                    name: json.name,
                    message: `登陆成功，欢迎${json.name}`,
                }))
                break;
            case format.al:
                nameList.forEach(item => {
                    if (item !== clientScoket) {
                        item.write(JSON.stringify({
                            type: format.al,
                            who: json.myName,
                            message: json.message
                        }))
                    }
                })
                break
        }

    })
})

server.listen(8989, () => { console.log('server is running at 127.0.0.1:8989') })