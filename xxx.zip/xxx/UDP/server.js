const dgram = require('dgram')
const server = dgram.createSocket('udp4')

server.on('listening', () => {
    const address = server.address()
    console.log(`server is running at ${address.address}:${address.port}`);
    server.setBroadcast(true)
    // 直接地址
    // 受限地址
    // 组播地址
    server.send('我是广播数据，你看我烦人不嘿~',9191,'255.255.255.255')
    setInterval(() => {
        server.send('我是广播数据，你看我烦人不嘿~',9191,'255.255.255.255')
    }, 2000)
})
server.on('message', (msg, remote) => {
    console.log(`${remote.address}:${remote.port} said: ${msg}`)
    server.send('我是服务端发送的消息~', remote.port, remote.address)
})
server.on('error', err => {
    console.log(`server err:${err}`)
})

server.bind(9090)