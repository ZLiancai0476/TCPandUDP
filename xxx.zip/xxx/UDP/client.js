const dgram = require('dgram')
const client = dgram.createSocket('udp4')

// client.send('我是客户端发送的消息~', 9090, '127.0.0.1')

client.on('listening', () => {
    const address = client.address()
    console.log(`server is running at ${address.address}:${address.port}`);
    // client.addMembership('组播网段')
})
client.on('message', (msg, remote) => {
    console.log(`${remote.address}:${remote.port} said: ${msg}`)
})
client.on('error', err => {
    console.log(`server err:${err}`)
})

client.bind(9191)